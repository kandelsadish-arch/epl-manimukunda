/* ==========================================================================
   Manimukunda Secondary College - EPL Interactive JavaScript & Three.js 3D
   ========================================================================== */

document.addEventListener('DOMContentLoaded', () => {
    initThreeJSBackground();
    init3DTiltEffects();
    initWeekProgramTabs();
    initWeek5PhotoUploader();
    initVoteCounter();
    initPledgeForm();
    initZipDownloader();
    initScrollAnimations();
});

/* --------------------------------------------------------------------------
   1. THREE.JS 3D GREEN LEAF / PARTICLES BACKGROUND
   -------------------------------------------------------------------------- */
function initThreeJSBackground() {
    const canvas = document.getElementById('three-canvas');
    if (!canvas || typeof Three === 'undefined' && typeof THREE === 'undefined') return;

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer({ canvas: canvas, alpha: true, antialias: true });

    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));

    // Particle Group (Floating Green Leaves / Eco Particles)
    const particleCount = 120;
    const geometry = new THREE.BufferGeometry();
    const positions = new Float32Array(particleCount * 3);
    const scales = new Float32Array(particleCount);

    for (let i = 0; i < particleCount; i++) {
        positions[i * 3] = (Math.random() - 0.5) * 40;     // X
        positions[i * 3 + 1] = (Math.random() - 0.5) * 40; // Y
        positions[i * 3 + 2] = (Math.random() - 0.5) * 20; // Z
        scales[i] = Math.random() * 0.4 + 0.1;
    }

    geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    geometry.setAttribute('scale', new THREE.BufferAttribute(scales, 1));

    // Leaf/Eco Glowing Particle Texture
    const particleMaterial = new THREE.PointsMaterial({
        color: 0x34d399,
        size: 0.35,
        transparent: true,
        opacity: 0.75,
        blending: THREE.AdditiveBlending
    });

    const particles = new THREE.Points(geometry, particleMaterial);
    scene.add(particles);

    camera.position.z = 15;

    // Mouse movement parallax
    let mouseX = 0;
    let mouseY = 0;

    window.addEventListener('mousemove', (e) => {
        mouseX = (e.clientX / window.innerWidth - 0.5) * 2;
        mouseY = (e.clientY / window.innerHeight - 0.5) * 2;
    });

    // Animation Loop
    function animate() {
        requestAnimationFrame(animate);

        particles.rotation.y += 0.0012;
        particles.rotation.x += 0.0006;

        // Camera subtle float
        camera.position.x += (mouseX * 2 - camera.position.x) * 0.03;
        camera.position.y += (-mouseY * 2 - camera.position.y) * 0.03;
        camera.lookAt(scene.position);

        renderer.render(scene, camera);
    }

    animate();

    // Window Resize Handler
    window.addEventListener('resize', () => {
        camera.aspect = window.innerWidth / window.innerHeight;
        camera.updateProjectionMatrix();
        renderer.setSize(window.innerWidth, window.innerHeight);
    });
}

/* --------------------------------------------------------------------------
   2. 3D TILT EFFECT FOR GLASS CARDS & HERO BADGES
   -------------------------------------------------------------------------- */
function init3DTiltEffects() {
    const tiltElements = document.querySelectorAll('[data-tilt], .card-3d-frame');

    tiltElements.forEach(el => {
        el.addEventListener('mousemove', (e) => {
            const rect = el.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;
            
            const centerX = rect.width / 2;
            const centerY = rect.height / 2;
            
            const rotateX = (y - centerY) / 15;
            const rotateY = (centerX - x) / 15;

            el.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) scale3d(1.02, 1.02, 1.02)`;
        });

        el.addEventListener('mouseleave', () => {
            el.style.transform = `perspective(1000px) rotateX(0deg) rotateY(0deg) scale3d(1, 1, 1)`;
        });
    });
}

/* --------------------------------------------------------------------------
   3. 5-WEEK PROGRAM TABS SWITCHER
   -------------------------------------------------------------------------- */
function initWeekProgramTabs() {
    const tabs = document.querySelectorAll('.week-tab');
    const panels = document.querySelectorAll('.week-card-content');

    tabs.forEach(tab => {
        tab.addEventListener('click', () => {
            const targetWeek = tab.getAttribute('data-week');

            // Update tab active state
            tabs.forEach(t => t.classList.remove('active'));
            tab.classList.add('active');

            // Show target panel
            panels.forEach(panel => {
                panel.classList.remove('active');
                if (panel.id === `week-${targetWeek}-panel`) {
                    panel.classList.add('active');
                }
            });
        });
    });
}

/* --------------------------------------------------------------------------
   4. WEEK 5 BLANK PHOTO FRAME & LIVE UPLOADER MANAGER
   -------------------------------------------------------------------------- */
function initWeek5PhotoUploader() {
    const fileInput = document.getElementById('week5-file-input');
    const resetBtn = document.getElementById('reset-week5-photo');
    const placeholderUI = document.getElementById('blank-placeholder-ui');
    const previewImg = document.getElementById('uploaded-week5-img');
    const dropZone = document.getElementById('blank-photo-container');
    const captionText = document.getElementById('week5-caption-text');

    if (!fileInput || !previewImg || !placeholderUI) return;

    // Load existing uploaded photo from LocalStorage if present
    const savedPhoto = localStorage.getItem('msc_epl_week5_photo');
    if (savedPhoto) {
        displayPhoto(savedPhoto);
    }

    // File input selection
    fileInput.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (file) {
            processFile(file);
        }
    });

    // Drag and Drop handlers
    dropZone.addEventListener('dragover', (e) => {
        e.preventDefault();
        dropZone.style.borderColor = 'var(--gold-accent)';
    });

    dropZone.addEventListener('dragleave', () => {
        dropZone.style.borderColor = '';
    });

    dropZone.addEventListener('drop', (e) => {
        e.preventDefault();
        dropZone.style.borderColor = '';
        if (e.dataTransfer.files && e.dataTransfer.files[0]) {
            processFile(e.dataTransfer.files[0]);
        }
    });

    // Reset button
    resetBtn.addEventListener('click', () => {
        localStorage.removeItem('msc_epl_week5_photo');
        previewImg.src = '';
        previewImg.classList.add('hidden');
        placeholderUI.classList.remove('hidden');
        captionText.innerHTML = `<i class="fa-solid fa-trophy"></i> Week 5: Grand Finale & Victory Photo - Manimukunda Secondary College`;
        fileInput.value = '';
    });

    function processFile(file) {
        if (!file.type.startsWith('image/')) {
            alert('Please select an image file (PNG, JPG, WebP, etc.).');
            return;
        }

        const reader = new FileReader();
        reader.onload = (e) => {
            const dataUrl = e.target.result;
            localStorage.setItem('msc_epl_week5_photo', dataUrl);
            displayPhoto(dataUrl);
        };
        reader.readAsDataURL(file);
    }

    function displayPhoto(dataUrl) {
        previewImg.src = dataUrl;
        previewImg.classList.remove('hidden');
        placeholderUI.classList.add('hidden');
        captionText.innerHTML = `<i class="fa-solid fa-square-check"></i> Official Week 5 Grand Finale Photo Loaded! (Manimukunda Secondary College)`;
    }
}

/* --------------------------------------------------------------------------
   5. VOTE COUNTER FOR MSC EPL CHAMPIONSHIP
   -------------------------------------------------------------------------- */
function initVoteCounter() {
    const voteBtn = document.getElementById('cast-vote-btn');
    const voteNumberEl = document.getElementById('vote-count');
    if (!voteBtn || !voteNumberEl) return;

    let currentVotes = parseInt(localStorage.getItem('msc_vote_count')) || 4892;
    let hasVoted = localStorage.getItem('msc_user_has_voted') === 'true';

    voteNumberEl.textContent = currentVotes.toLocaleString();

    if (hasVoted) {
        voteBtn.disabled = true;
        voteBtn.innerHTML = `<i class="fa-solid fa-circle-check"></i> Vote Casted! Thank You for Supporting MSC`;
        voteBtn.style.background = 'linear-gradient(135deg, #059669 0%, #047857 100%)';
    }

    voteBtn.addEventListener('click', () => {
        if (hasVoted) return;

        currentVotes += 1;
        voteNumberEl.textContent = currentVotes.toLocaleString();
        localStorage.setItem('msc_vote_count', currentVotes);
        localStorage.setItem('msc_user_has_voted', 'true');

        hasVoted = true;
        voteBtn.disabled = true;
        voteBtn.innerHTML = `<i class="fa-solid fa-circle-check"></i> Vote Casted! Thank You for Supporting MSC`;
        voteBtn.style.background = 'linear-gradient(135deg, #059669 0%, #047857 100%)';

        createConfettiEffect(voteBtn);
    });
}

/* --------------------------------------------------------------------------
   6. PLEDGE FORM & LIVE WALL
   -------------------------------------------------------------------------- */
function initPledgeForm() {
    const form = document.getElementById('pledge-form');
    const pledgesList = document.getElementById('pledges-list');
    if (!form || !pledgesList) return;

    form.addEventListener('submit', (e) => {
        e.preventDefault();

        const name = document.getElementById('pledger-name').value.trim();
        const role = document.getElementById('pledger-role').value;
        const message = document.getElementById('pledger-message').value.trim();

        if (!name || !message) return;

        // Create new item
        const newItem = document.createElement('div');
        newItem.className = 'pledge-card-item';
        newItem.style.animation = 'fadeIn 0.5s ease forwards';
        newItem.innerHTML = `
            <div class="pledger-meta">
                <strong>${escapeHTML(name)}</strong>
                <span class="role-badge">${escapeHTML(role)}</span>
            </div>
            <p>"${escapeHTML(message)}"</p>
        `;

        pledgesList.prepend(newItem);
        form.reset();

        alert('Thank you for pledging your support for Manimukunda Secondary College in the EPL 2026!');
    });

    function escapeHTML(str) {
        return str.replace(/[&<>'"]/g, 
            tag => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[tag] || tag)
        );
    }
}

/* --------------------------------------------------------------------------
   7. ZIP DOWNLOADER (BUNDLES SOURCE CODE & ASSETS FOR USER DOWNLOAD)
   -------------------------------------------------------------------------- */
function initZipDownloader() {
    const downloadBtn = document.getElementById('download-zip-btn');
    if (!downloadBtn || typeof JSZip === 'undefined' || typeof saveAs === 'undefined') return;

    downloadBtn.addEventListener('click', async () => {
        downloadBtn.innerHTML = `<i class="fa-solid fa-spinner fa-spin"></i> Zipping Files...`;
        downloadBtn.disabled = true;

        try {
            const zip = new JSZip();

            // Fetch HTML, CSS, JS text
            const htmlText = await fetch('index.html').then(r => r.text());
            const cssText = await fetch('styles.css').then(r => r.text());
            const jsText = await fetch('app.js').then(r => r.text());

            zip.file('index.html', htmlText);
            zip.file('styles.css', cssText);
            zip.file('app.js', jsText);

            // Fetch images in assets folder
            const assetsFolder = zip.folder('assets');
            
            try {
                const heroBlob = await fetch('assets/hero_bg.png').then(r => r.blob());
                assetsFolder.file('hero_bg.png', heroBlob);
            } catch (err) { console.log('Hero bg fetch optional', err); }

            try {
                const cleanupBlob = await fetch('assets/week1_cleanup.png').then(r => r.blob());
                assetsFolder.file('week1_cleanup.png', cleanupBlob);
            } catch (err) { console.log('Cleanup bg fetch optional', err); }

            // Generate ZIP file
            const zipContent = await zip.generateAsync({ type: 'blob' });
            saveAs(zipContent, 'Manimukunda_Secondary_College_EPL_Website.zip');

            downloadBtn.innerHTML = `<i class="fa-solid fa-circle-check"></i> Downloaded!`;
            setTimeout(() => {
                downloadBtn.innerHTML = `<i class="fa-solid fa-file-arrow-down"></i> <span>Download Files</span>`;
                downloadBtn.disabled = false;
            }, 3000);

        } catch (error) {
            console.error('Download error:', error);
            alert('Downloading files... You can also save the page directly from your browser.');
            downloadBtn.innerHTML = `<i class="fa-solid fa-file-arrow-down"></i> <span>Download Files</span>`;
            downloadBtn.disabled = false;
        }
    });
}

/* Confetti Micro-Effect */
function createConfettiEffect(targetEl) {
    for (let i = 0; i < 20; i++) {
        const confetti = document.createElement('div');
        confetti.style.position = 'fixed';
        confetti.style.width = '8px';
        confetti.style.height = '8px';
        confetti.style.backgroundColor = ['#10b981', '#34d399', '#f59e0b', '#6ee7b7'][Math.floor(Math.random() * 4)];
        confetti.style.borderRadius = '50%';

        const rect = targetEl.getBoundingClientRect();
        confetti.style.left = `${rect.left + rect.width / 2}px`;
        confetti.style.top = `${rect.top}px`;
        confetti.style.zIndex = '9999';
        confetti.style.pointerEvents = 'none';

        document.body.appendChild(confetti);

        const angle = Math.random() * Math.PI * 2;
        const velocity = Math.random() * 100 + 50;
        const vx = Math.cos(angle) * velocity;
        const vy = Math.sin(angle) * velocity - 100;

        let startTime = performance.now();

        function updateConfetti(currentTime) {
            const elapsed = (currentTime - startTime) / 1000;
            if (elapsed > 1.2) {
                confetti.remove();
                return;
            }

            const currentX = rect.left + rect.width / 2 + vx * elapsed;
            const currentY = rect.top + vy * elapsed + 300 * elapsed * elapsed;
            confetti.style.left = `${currentX}px`;
            confetti.style.top = `${currentY}px`;
            confetti.style.opacity = `${1 - elapsed / 1.2}`;

            requestAnimationFrame(updateConfetti);
        }

        requestAnimationFrame(updateConfetti);
    }
}

/* Scroll Animations */
function initScrollAnimations() {
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
            }
        });
    }, { threshold: 0.1 });

    document.querySelectorAll('.glass-panel, .pillar-card, .impact-card, .reason-card').forEach(el => {
        observer.observe(el);
    });
}
